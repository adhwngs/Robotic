#Get input from the user
name = input("What's your name? ")

#print the result
print("Nice to meet you, " + name)